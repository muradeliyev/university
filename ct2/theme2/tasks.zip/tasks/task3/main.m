clc;
close all;

syms k;
f = k^2;
F = ztrans(f);

disp(F);
